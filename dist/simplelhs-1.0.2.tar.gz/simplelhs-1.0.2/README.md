# simplelhs
Simple implementation of Latin Hypercube Sampling.
